package com.Meta;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class Email_ValidOR_Not {

	public static boolean isValid(String email) {
		String r = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@*" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";

		Pattern patt = Pattern.compile(r);
		if (email == null)
			return false;
		return patt.matcher(email).matches();
	}

	public static void main(String[] args) {
		ArrayList<String> addr = new ArrayList<>();
		addr.add("student01@gmail.com");
		addr.add("test01*gmail.com");

		for (String i : addr) {
			if (isValid(i)) {
				System.out.println(i + "- Valid Emaild id");
			} else {
				System.out.println(i + "- Invalid Email id");
			}
		}
	}

}
