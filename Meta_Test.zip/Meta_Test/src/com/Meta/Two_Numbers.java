package com.Meta;

import java.util.Scanner;

class A {
	void show() {
		System.out.print("Enter Two Numbers :");
		Scanner sc = new Scanner(System.in);
		int[] a = new int[1];
		int[] b = new int[1];
		for (int i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
		}
		for (int i = 0; i < a.length; i++) {
			System.out.println("First Number" + a[i]);
		}
		for (int i = 0; i < b.length; i++) {
			b[i] = sc.nextInt();
		}
		for (int i = 0; i < b.length; i++) {
			System.out.println("Secon Number" + b[i]);
		}

	}
}

class B extends A {
	void fetch(int[] a, int[] b) {// 1234 6566 {
		a.toString();
		System.out.println(a);
	}
}

class C {

}

public class Two_Numbers {

	public static void main(String[] args) {
		A a = new A();
		a.show();
	}

}
