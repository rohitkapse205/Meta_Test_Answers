package com.Meta;

public class RemoveDuplicateElements {

	public static void main(String[] args) {
		int count = 0;
		String s = "dummy text of the printing and typesetting industry.";
		for (int i = 0; i < s.length(); i++) {
			for(int j=0;j<)
			char ch = s.charAt(i);
			
			if (s.charAt(i) != ' ') {
				count++;
			}

		}

	}

}
